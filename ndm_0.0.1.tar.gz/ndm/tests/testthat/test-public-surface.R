test_that("runtime implementation helpers are not part of the public surface", {
  exports <- getNamespaceExports("ndm")

  expect_false("ndm_run_analysis2_real" %in% exports)
  expect_false("ndm_run_analysis2_sim" %in% exports)
  expect_false("ndm_run_analysis2_multidisease" %in% exports)
  expect_false("ndm_runtime_paths" %in% exports)
  expect_false("ndm_load_runtime" %in% exports)
  expect_false("ndm_source_runtime_helper_fxns" %in% exports)
  expect_false("ndm_source_runtime_backend" %in% exports)
  expect_false("ndm_source_runtime_data" %in% exports)
  expect_false("ndm_source_runtime_calibration" %in% exports)
  expect_false("ndm_source_runtime_results_get" %in% exports)
  expect_false("ndm_source_runtime_results_analyze" %in% exports)
})

test_that("run configs no longer expose project-specific figure toggles", {
  real_cfg <- ndm_create_real_run_config(project_root = tempdir(), grid = data.frame(BaseID = 1L), dry_run = TRUE)
  sim_cfg <- ndm_create_sim_run_config(project_root = tempdir(), grid = data.frame(BaseID = 1L), dry_run = TRUE)
  multi_cfg <- ndm_create_multidisease_run_config(project_root = tempdir(), grid = data.frame(BaseID = 1L), dry_run = TRUE)

  expect_false("run_figures" %in% names(real_cfg))
  expect_false("run_figures" %in% names(sim_cfg))
  expect_false("run_figures" %in% names(multi_cfg))
})
